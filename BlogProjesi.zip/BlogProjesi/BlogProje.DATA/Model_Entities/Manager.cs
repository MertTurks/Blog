﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogProje.DATA.Model_Entities
{
    //Yönetici
    public class Manager
    {
        [Key]
        public int ManagerID { get; set; }
        [Required]
        public int TC { get; set; }
        [Required,MaxLength(50)]
        public string Name { get; set; }
        [Required,MaxLength(150)]
        public string LastName { get; set; }
        [Required,MaxLength(20)]
        public string UserName { get; set; }
        [MaxLength(500)]
        public string Photo { get; set; }

        [Required,ForeignKey("User")]
        public int UserID { get; set; }

        public virtual User User { get; set; }
    }
}
