﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogProje.DATA.Model_Entities
{
    //Makale
    public class Article
    {
        [Key]
        public int ArticleID { get; set; }
        [Required,MaxLength(150)]
        public string Title { get; set; } //başlık
        [Required]
        public string Content { get; set; } //içerik
        [MaxLength(500)]
        public string Picture { get; set; }
        [Column(TypeName = "datetime2")]
        public DateTime DateTime { get; set; }
        [Required,ForeignKey("Category")]
        public int CategoryID { get; set; }
        [Required, ForeignKey("Member")]
        public int MemberID { get; set; } //üyeID
        public int ReadCount { get; set; } //okunma sayısı
        public int Voting { get; set; } //oylama


        public virtual Category Category { get; set; }
        public virtual List<Comment> Comments { get; set; }

        public virtual Member Member { get; set; }
    }
}
