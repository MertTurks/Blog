﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogProje.DATA.Model_Entities
{
    //yorum
    public class Comment
    {
        [Key]
        public int CommentID { get; set; }
        
        public string Content { get; set; } //içerik
        [Required,ForeignKey("Member")]
        public int MemberID { get; set; } //üyeıd
        [Required,ForeignKey("Article")]
        public int ArticleID { get; set; } //makaleıd
        public DateTime CommentDate { get; set; } //yorumtarihi

        public virtual Article Article { get; set; }
    }
}
