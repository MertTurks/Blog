﻿using BlogProjesi.Identity_Entity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Identity_Entity
{
    public class IdentityDataContext : IdentityDbContext<ApplicationUser>
    {
    }
}
